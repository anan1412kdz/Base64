import base64
import os
from time import sleep
from pystyle import Colors, Colorate
from rich.console import Console
import time
console = Console()

def Write_Print(text, color, interval):
    for char in text:
        console.print(char, style=color, end="")
        time.sleep(interval)
    print() 

if __name__ == '__main__':
    os.system('cls' if os.name == 'nt' else 'clear')
    Write_Print("""
                                                                    
                         ,--.                                  ,--. 
   ,---,               ,--.'|            ,---,               ,--.'| 
  '  .' \          ,--,:  : |           '  .' \          ,--,:  : | 
 /  ;    '.     ,`--.'`|  ' :          /  ;    '.     ,`--.'`|  ' : 
:  :       \    |   :  :  | |         :  :       \    |   :  :  | | 
:  |   /\   \   :   |   \ | :         :  |   /\   \   :   |   \ | : 
|  :  ' ;.   :  |   : '  '; |         |  :  ' ;.   :  |   : '  '; | 
|  |  ;/  \   \ '   ' ;.    ;         |  |  ;/  \   \ '   ' ;.    ; 
'  :  | \  \ ,' |   | | \   |         '  :  | \  \ ,' |   | | \   | 
|  |  '  '--'   '   : |  ; .'         |  |  '  '--'   '   : |  ; .' 
|  :  :         |   | '`--'           |  :  :         |   | '`--'   
|  | ,'         '   : |               |  | ,'         '   : |       
`--''           ;   |.'               `--''           ;   |.'       
                '---'                                 '---'         
    ╔══════════════════════════════════════════════════════╗
    ║     Data Encryption     | Develop by: AnAn           ║
    ╚══════════════════════════════════════════════════════╝                                                                    
    \n""", "blue", 0.0009)

    input_dir = "FileCanMaHoa"
    output_dir = "FileDaDuocMaHoa"
    os.makedirs(input_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    file_name = input(Colorate.Diagonal(Colors.purple_to_blue, "Nhập tên tệp cần mã hóa: "))
    file_path = os.path.join(input_dir, file_name)

    if not os.path.isfile(file_path):
        print(Colorate.Diagonal(Colors.purple_to_blue, f"Tệp {file_name} không tồn tại trong thư mục {input_dir}."))
        exit()

    # Đọc nội dung tệp và mã hóa
    with open(file_path, 'rb') as file:
        file_content = file.read()

    encoded_content = base64.b64encode(file_content)

    # Ghi tệp mã hóa
    encoded_file_path = os.path.join(output_dir, f'{file_name}')
    with open(encoded_file_path, 'wb') as encoded_file:
        encoded_file.write(encoded_content)

    print(Colorate.Diagonal(Colors.purple_to_blue, "Tệp đã được mã hóa thành công!"))
    sleep(2)

    try:
        # Tạo mã Python để giải mã
        python_code = f"""import base64

encoded_content = {repr(encoded_content.decode('utf-8'))}

decoded_content = base64.b64decode(encoded_content.encode('utf-8'))
exec(decoded_content.decode('utf-8'))
"""

        python_file_path = os.path.join(output_dir, f"{file_name}")
        with open(python_file_path, 'w') as python_file:
            python_file.write(python_code)

        print(Colorate.Diagonal(Colors.purple_to_blue, f"File mã hóa đã được lưu trong thư mục {output_dir}!"))
    except Exception as e:
        print(Colorate.Diagonal(Colors.red_to_white, f"Đã xảy ra lỗi: {e}"))